package Classes;

public class Employee {
    String name; //protected
    public  String address;
    private  double salary;

}
