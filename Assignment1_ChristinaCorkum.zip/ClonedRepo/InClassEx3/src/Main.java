//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {
    /*
   Create a program with two classes: Main and House
Main will be used as the “run the program” class,
creating and interacting with instances of the House class.
In the House class, define properties for:
Length, width and at least two other properties (your choice).
A method called printTotalArea(), which prints the total square footage of the house to the console.
Another method (your choice), that can simply print a description of its action to the console.
Remember that properties are used to describe attributes of an object, while methods are actions the object can do.
Don’t forget to add a constructor to your House class, that sets each property!
Once the House class is defined to your satisfaction,
create three instances of different House objects from your Main class, assigning property values via the constructor.
Write code to invoke the methods of each of the House objects you instantiated. At minimum, each house object’s area should be printed.

     */

//    create three instances of different House objects from your Main class,
//    assigning property values via the constructor.

    House firstHouse = new House(200.5,150.2,2,"Halifax");
    House secondHouse = new House(300,200.5,3,"Antigonish");
    House thirdHouse = new House(310,250.6,4,"Middle SackVille");


//    Write code to invoke the methods of each of the House objects you instantiated.
//    At minimum, each house object’s area should be printed.

    firstHouse.printTotalArea();
    firstHouse.report();

    secondHouse.printTotalArea();
    secondHouse.report();

    thirdHouse.printTotalArea();
    thirdHouse.report();



}
