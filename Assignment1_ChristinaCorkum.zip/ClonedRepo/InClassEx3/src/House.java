public class House {
    /*
    In the House class, define properties for:
Length, width and at least two other properties (your choice).
A method called printTotalArea(), which prints the total square footage of the house to the console.
Another method (your choice), that can simply print a description of its action to the console.
Remember that properties are used to describe attributes of an object,
while methods are actions the object can do.
Don’t forget to add a constructor to your House class, that sets each property!
     */
    //1. Attributes:
    public double length;
    public double width;
    public int bedRooms;
    public String address;

    //2. Constructor(s):
    //Don’t forget to add a constructor to your House class,
    // that sets each property!


    public House(double length, double width, int bedRooms, String address) {
        this.length = length;
        this.width = width;
        this.bedRooms = bedRooms;
        this.address = address;
    }

    //3. Method(s):

    /*
    A. A method called printTotalArea(),
    which prints the total square footage of the house to the console.
    B. Another method (your choice), that can simply print a description of
    its action to the console.
     */


    //

    //A. printTotalArea()
    public void printTotalArea(){
        Double area = this.length * this.width;
        System.out.println("The area of the house is: " + area + " footage");
    }

    //B. report():
    public void report(){
        String report = String.format("Length: %.2f -\tWidth: %.2f -\t" +
                "Number of bedrooms: %d -\tAddress: %s",this.length,
                this.width,this.bedRooms,
                this.address);
        System.out.println(report);
    }

    public void report2(){
        System.out.println("Thank you");
    }

}
