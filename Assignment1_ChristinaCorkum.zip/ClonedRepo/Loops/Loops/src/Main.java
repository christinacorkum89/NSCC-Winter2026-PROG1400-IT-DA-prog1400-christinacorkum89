public class Main {
    public static void main(String[] args){
        System.out.println("Loops Examples: ");
        System.out.println("For Loop ================");
        for (int i = 0;i <10; i++) {
            System.out.println(i);
        }
        for (int i = 10; i < 20; i++) {
            System.out.println("I= " + i);
        }
        for (int i = 20; i < 40; i = i +2) {
                System.out.println("I= "  +i);
        }

        System.out.println("Nested Loop");
        for (int i = 0; i < 10; i++) {
            for (int j = 10; j > 0; j--) {
                System.out.println("I= " +i +" J= : " + j);
            } // End of the inner loop (j loop)

        } //The end of the outer loop (i loop)

        System.out.println("While Loop ======================");
        int k = 0;
        while (k < 10) {
            System.out.println(k);
            k += 2;
        }

        System.out.println("Do While Loop ============");
        int counter = 12;
        do {
            System.out.println(counter);
            counter--;
        } while (counter >4);
    }
}
