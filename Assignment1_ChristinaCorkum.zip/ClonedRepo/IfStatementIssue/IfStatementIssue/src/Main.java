import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("If Statement Issue!");
        Scanner sc = new Scanner(System.in);
        String city,stdName;
        System.out.print("Enter your name: ");
        stdName = sc.nextLine();
        System.out.println("Enter your city: ");
        city = sc.nextLine();
        System.out.println("Your name is: "  + stdName);
        if (city == "Halifax")
            System.out.println("Welcome to IT Campus!");
        else
            System.out.println("You are from another campus!");
        //the proper if statement:
        System.out.println("The proper if statement:");
        if (city.equals("Halifax"))
            System.out.println("Welcome to IT Campus!");
        else
            System.out.println("You are from another campus!");


    }
}