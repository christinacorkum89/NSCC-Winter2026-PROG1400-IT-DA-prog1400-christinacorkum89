void main() {
    System.out.println("Scanner Example 2");
    //className objectName = new className
    //I will declare a new Scanner object called sc:
    Scanner sc = new Scanner(System.in);
    //I will declare a new variable:
    System.out.println("Enter the student's name: ");
    String stdName = sc.nextLine();
    System.out.println("Enter the student's grade: ");
    double stdGrade = sc.nextDouble();
    System.out.println("Enter the student's age");
    int stdAge = sc.nextInt();
    sc.nextLine(); //To resolve the scanner's issue
    System.out.println("Enter your address: ");
    String stdAddress = sc.nextLine();

    System.out.println("Student's report");
    System.out.println("=".repeat(50));
    System.out.println("Student's Name: " + stdName);
    System.out.println("Student's Address: " + stdAddress);
    System.out.println("Student's Grade: " + stdGrade);

    if (stdGrade >=60) {
        System.out.println("You pass the course. Congrats!");
    }
    else{
        System.out.println("You failed the course unfortunately");
    }

}
