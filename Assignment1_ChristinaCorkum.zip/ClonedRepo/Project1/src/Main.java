//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {
    //public static void main() method
    //This is my first project in Java:
    //Keep in your mind to capitalize the first letter of any word if
    //it is a built-in class or user-defined class.

    System.out.println("Welcome to our first project");
    //Declaring new variables:
    double salary = 18000.50;
    double tax = 0.25;
    double netSalary = salary * (1-tax);
    System.out.println("The net Salary is: $" + netSalary);

}
