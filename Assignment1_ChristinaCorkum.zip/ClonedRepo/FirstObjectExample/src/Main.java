//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {
    //Any class in Java, consists of three main parts:
    //1. Attributes/Properties/fields/states:
    //I will declare the following attributes:
    public String carsMake;
    public String carsModel;
    public String carsColor;
    public int year;

    //2. The Constructors:
    //In the constructor, we assign value to the attributes(s).
    //We have three types of Constructors:
    //A. The default hidden constructor:
    // It will assign
    }
}
