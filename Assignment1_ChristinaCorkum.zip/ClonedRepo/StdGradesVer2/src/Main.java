import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        /*
        A student's grade project. This program gathers grades
        from the console and displays them.
        Date: Jan 15, 2026
        */
        double[] stdGrades = new double[3];
        Scanner sc = new Scanner(System.in);

        System.out.println("Gathering the student's grades:");

        for (int i = 0; i < stdGrades.length; i++) {
            while (true) {
                System.out.print("Enter student's grade #" + (i + 1) + ": ");
                if (sc.hasNextDouble()) {
                    stdGrades[i] = sc.nextDouble();
                    break;
                } else {
                    System.out.println("Invalid input. Please enter a numeric grade.");
                    sc.next(); // discard invalid input
                }
            }
        }

        System.out.println("\nThe student's grades are:");
        System.out.println("==========================");

        for (int i = 0; i < stdGrades.length; i++) {
            System.out.println("Grade #" + (i + 1) + ": " + stdGrades[i]);
        }

        sc.close();
        System.out.println("\nProgram completed successfully.");
    }
}